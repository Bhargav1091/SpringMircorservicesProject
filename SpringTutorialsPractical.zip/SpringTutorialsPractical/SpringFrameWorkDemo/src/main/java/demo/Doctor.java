package demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

public class Doctor implements Staff {
        public void assist(){
            System.out.println("Doctor is assisting");
    }
}
