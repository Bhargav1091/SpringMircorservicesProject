package com.dailycodebuffer.spring.data.jpa.tutorial.spring.data.jpa.tutorial.repository;

import com.dailycodebuffer.spring.data.jpa.tutorial.spring.data.jpa.tutorial.entity.Guardian;
import com.dailycodebuffer.spring.data.jpa.tutorial.spring.data.jpa.tutorial.entity.Student;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
// @DataJpaTest :VVIMp for Interview
class StudentRepositoryTest {

    @Autowired
    StudentRepository repository;

    @Test
    public void saveStudent(){
         // Below snippet called Builder pattern
        Student student = Student.builder()
                .emailId("abc@gmail.com").
                firstName("Bhargav").
                lastName("Thakkar")
                //guardianName("Test").
                //guardianEmail("test@gmail.com").
                //gurdianMobile("765757657575")
                .build();

        repository.save(student);

    }

    @Test
    public void printAllStudent(){

        List<Student> studentList = repository.findAll();
        System.out.println(studentList);
    }

    @Test
    public void saveStudentWithGuardian(){
        Guardian guardian = Guardian.builder().
                email("test@gmail").name("Test").
                mobile("56456465").
                build();

                Student student = Student.builder().
                        emailId("abc@gmail.com").
                        firstName("Bhargav").
                        lastName("Thakkar").guardian(guardian).build();

                repository.save(student);
    }

    @Test
    public void printStudentByFirstName(){

        List<Student> studentList = repository.findByFirstName("Bhargav");
        System.out.println(studentList);
    }

    @Test
    public void printStudentByFirstNameContaining(){
        List<Student> studentList = repository.findByFirstNameContaining("Bha"  );
        System.out.println(studentList);
    }

    @Test
    public void printStudentByEmailAddress(){

        Student student = repository.getStudenByEmailAddress("Test@gmail.com");
        System.out.println(student);

    }

    @Test
    public void printgetStudenByEmailAddressNative(){
        Student student = repository.getStudenByEmailAddressNative("test@gmail.com");
    }

}