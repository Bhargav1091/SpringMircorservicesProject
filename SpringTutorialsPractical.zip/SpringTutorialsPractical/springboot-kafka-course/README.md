# Spring Boot + Apache Kafka - The Quickstart Practical Guide- Udemy course

Course link: https://www.udemy.com/course/spring-boot-and-apache-kafka/?referralCode=545DF9E4BA28DAAA2832

# Blog posts on JavaGuides
Spring Boot Kafka Producer Consumer Example Tutorial - https://www.javaguides.net/2022/05/spring-boot-kafka-producer-consumer-example-tutorial.html

Spring Boot Kafka JsonSerializer and JsonDeserializer Example - https://www.javaguides.net/2022/05/spring-boot-kafka-jsonserializer-and-Jsondeserializer-example.html
