package demo;

import org.springframework.stereotype.Component;

@Component

public class ShoppingCart {
    public void checkout(String input){
        System.out.println("Checkout method called");
    }
}
