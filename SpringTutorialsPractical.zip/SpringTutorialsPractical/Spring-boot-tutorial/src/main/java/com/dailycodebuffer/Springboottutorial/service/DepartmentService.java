package com.dailycodebuffer.Springboottutorial.service;

import com.dailycodebuffer.Springboottutorial.entity.Department;
import com.dailycodebuffer.Springboottutorial.error.DepartmentNotFound;

import java.util.List;

public interface DepartmentService {


    public  List<Department> fetchDepartment();

    public Department saveDepartment(Department department);

    public  Department fetchDepartmentbyID(Long departmentId) throws DepartmentNotFound;

    public void deleteDepartmenById(Long departmentId);

    public Department updateDeaprtment(Long departmentId, Department department);

    public Department fetchByDepartmentName(String departmentName);
}
