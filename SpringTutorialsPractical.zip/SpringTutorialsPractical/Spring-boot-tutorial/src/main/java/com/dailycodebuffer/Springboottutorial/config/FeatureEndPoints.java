package com.dailycodebuffer.Springboottutorial.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.Selector;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
@Endpoint(id="feature")
public class FeatureEndPoints {
    private final Map<String, Feature> featuremap = new ConcurrentHashMap<>();

    public FeatureEndPoints() {
        featuremap.put("Department", new Feature(true));
        featuremap.put("User", new Feature(false));
        featuremap.put("Authentication", new Feature(false));
    }

    @ReadOperation
    public Map<String ,Feature> features(){
        return featuremap;
    }

    @ReadOperation
    public Feature feature (@Selector String featureName){

        return featuremap.get(featureName);
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    private static class Feature{
        private boolean isEnabled;

    }
}
