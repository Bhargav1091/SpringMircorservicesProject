package com.dailycodebuffer.Springboottutorial.controller;

import com.dailycodebuffer.Springboottutorial.entity.Department;
import com.dailycodebuffer.Springboottutorial.error.DepartmentNotFound;
import com.dailycodebuffer.Springboottutorial.service.DepartmentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;


@RestController
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    private Logger LOGGER = LoggerFactory.getLogger(DepartmentController.class);

    @PostMapping("/departments")
    public Department saveDepartment(@Valid @RequestBody  Department department){
        LOGGER.info("Inside Save Department");
        return departmentService.saveDepartment(department);

    }

    @GetMapping("/departments")
    public List<Department> fetchDepartment(){
        return departmentService.fetchDepartment();

    }

    @GetMapping("/departments/{id}")
    public Department fetchDepartmentbyID(@PathVariable("id") Long departmentId) throws DepartmentNotFound {

        return departmentService.fetchDepartmentbyID(departmentId);

    }
    @DeleteMapping(("/departments/{id}"))
    public String deleteDepartmenById(@PathVariable("id") Long departmentId){
        departmentService.deleteDepartmenById(departmentId);

        return "Successfully Deleted !!!";
    }

    @PutMapping("/departments/{id}")
    public Department updateDeaprtment(@PathVariable("id") Long departmentId,@RequestBody Department department){

        return departmentService.updateDeaprtment(departmentId,department);

    }

    @GetMapping("/departments/name/{name}")
    public Department fetchByDepartmentName(@PathVariable("name") String departmentName){
        return departmentService.fetchByDepartmentName(departmentName);

    }
}
