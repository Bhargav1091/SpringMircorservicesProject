package com.dailycodebuffer.Springboottutorial.service;

import com.dailycodebuffer.Springboottutorial.entity.Department;
import com.dailycodebuffer.Springboottutorial.error.DepartmentNotFound;
import com.dailycodebuffer.Springboottutorial.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.swing.text.html.Option;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class DepartmentServiceImpl implements DepartmentService{

    @Autowired
    private DepartmentRepository repository;

    @Override
    public List<Department> fetchDepartment() {
        return repository.findAll();
    }

    @Override
    public Department saveDepartment(Department department) {

        return repository.save(department);
    }

    @Override
    public Department fetchDepartmentbyID(Long departmentId) throws DepartmentNotFound {

        Optional<Department> department = repository.findById(departmentId);

        if (!department.isPresent()){
            throw new DepartmentNotFound("Department Not Found");
        }
        return department.get();
    }

    @Override
    public void deleteDepartmenById(Long departmentId) {
        repository.deleteById(departmentId);
    }

    @Override
    public Department updateDeaprtment(Long departmentId, Department department) {

        Department dpDB = repository.findById(departmentId).get();
        if(Objects.nonNull(department.getDepartmentName()) && !"".equalsIgnoreCase(department.getDepartmentName())){
            dpDB.setDepartmentName(department.getDepartmentName());
        }

        if(Objects.nonNull(department.getDepartmentCode()) && !"".equalsIgnoreCase(department.getDepartmentCode())){
            dpDB.setDepartmentCode(department.getDepartmentCode());
        }

        if(Objects.nonNull(department.getDepartmentAddress()) && !"".equalsIgnoreCase(department.getDepartmentAddress())){
            dpDB.setDepartmentAddress(department.getDepartmentAddress());
        }

        return repository.save(dpDB);
    }

    @Override
    public Department fetchByDepartmentName(String departmentName) {
        return repository.findByDepartmentName(departmentName);
    }
}
