package com.dailycodebuffer.Springboottutorial.service;

import com.dailycodebuffer.Springboottutorial.entity.Department;
import com.dailycodebuffer.Springboottutorial.repository.DepartmentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class DepartmentServiceTest {

    @MockBean
    private DepartmentRepository repository;

    @BeforeEach
    OngoingStubbing<Department> setUp() {

        Department department =  Department.builder()
                .departmentName("IT")
                .departmentAddress("Ahmedabad")
                .departmentCode("IT-06")
                .departmentId(1l).
                build();

        return Mockito.when(repository.findByDepartmentName("IT")).
                thenReturn(department);
    }

    @Autowired
    private  DepartmentService departmentService;

    @Test
    public void whenValidDepartmentName_thenDepartmenShouldFound(){

        String departmentNmae ="IT";
        Department found = departmentService.fetchByDepartmentName(departmentNmae);

        assertEquals(departmentNmae,found.getDepartmentName());

    }
}