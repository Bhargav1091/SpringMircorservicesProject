package com.dailycodebuffer.user.service.VO;

import com.dailycodebuffer.user.service.entity.UserEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseTemplateVO {

    private UserEntity user;
    private Department department;
}
