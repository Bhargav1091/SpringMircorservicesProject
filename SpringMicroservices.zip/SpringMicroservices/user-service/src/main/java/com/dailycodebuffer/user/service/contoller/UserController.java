package com.dailycodebuffer.user.service.contoller;

import com.dailycodebuffer.user.service.VO.ResponseTemplateVO;
import com.dailycodebuffer.user.service.entity.UserEntity;
import com.dailycodebuffer.user.service.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
@Slf4j
public class UserController {

    @Autowired
   private UserService service;

    @PostMapping("/")
    public UserEntity saveUser(@RequestBody UserEntity user){
        log.info("Inside saveUser of User controller");
        return service.saveUser(user);

    }
    @GetMapping("/{id}")
    public ResponseTemplateVO getUserWithDepartment(@PathVariable("id") Long userId){
        log.info("Inside getUserwithDepartment of User controller");
        return service.getUserWithDepartment(userId);
    }
}
